class JobStatus {

    public name:string;
    public address:string;
    private retired:bool;


constructor() {
        this.retired = false;
    this.name= "aaa";
    }


}


