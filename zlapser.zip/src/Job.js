var JobStatus = (function () {
    function JobStatus() {
        this.retired = false;
        this.name = "aaa";
    }
    return JobStatus;
})();
//@ sourceMappingURL=Job.js.map
